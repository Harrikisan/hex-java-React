package com.hex.store.Service;

import java.time.LocalDate;

import com.hex.store.Dao.Impl.PurchaseDaoImpl;
import com.hex.store.Enum.Cupon;
import com.hex.store.Exception.InvalidInputException;
import com.hex.store.Model.Purchase;

public class PurchaseService {

	PurchaseDaoImpl dao=new PurchaseDaoImpl();
	public void insert(Purchase purchase) {
		// TODO Auto-generated method stub
		int id=(int)(Math.random()*1000);
		purchase.setId(id);
		purchase.setDate(LocalDate.now());
		try {
			dao.AddPurchase(purchase);
		} catch (InvalidInputException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
	}

}
