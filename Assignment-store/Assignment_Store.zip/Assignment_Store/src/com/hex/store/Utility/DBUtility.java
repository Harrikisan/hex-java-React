package com.hex.store.Utility;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.SQLException;


public class DBUtility {

	private  String URL="jdbc:mysql://localhost:3306/store_db";
	private  String user="root";
	private  String password="";
	private  String driver="com.mysql.cj.jdbc.Driver";
	private  Connection conn;
	private static DBUtility db=new DBUtility();
	
	public DBUtility() {}
	
	public static DBUtility getInstance() {
		return db;
	}
	
	public Connection getConnection() {
		
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		try {
			conn=DriverManager.getConnection(URL, user, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return conn;
	}
	
	public  void closeConnection() {
		 
			try {
				if(!conn.isClosed())
					conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		
	}
}
