package com.hex.store.Enum;

public enum Status {
	IN_STOCK,OUT_OF_STOCK;
}
