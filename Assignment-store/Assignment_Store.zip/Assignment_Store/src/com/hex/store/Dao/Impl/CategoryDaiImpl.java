package com.hex.store.Dao.Impl;

import com.hex.store.Dao.CategoryDao;

public class CategoryDaiImpl implements CategoryDao{

}
