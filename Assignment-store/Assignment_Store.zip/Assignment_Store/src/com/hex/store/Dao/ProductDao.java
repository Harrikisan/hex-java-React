package com.hex.store.Dao;

import java.util.List;

import com.hex.store.Exception.InvalidIdException;
import com.hex.store.Exception.InvalidInputException;
import com.hex.store.Model.Product;

public interface ProductDao {

	public void AddProduct(Product product) throws InvalidInputException;
	public List<Product> GetProductByCategory(int id) throws InvalidIdException;
}
