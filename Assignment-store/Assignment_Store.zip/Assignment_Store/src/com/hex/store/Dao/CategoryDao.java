package com.hex.store.Dao;

public interface CategoryDao {

	/**
	 * This data is asked to be manually inserted in the database, 
	 * So there will be no method declaration here, Also no implementation in DaoImpl **/
}
