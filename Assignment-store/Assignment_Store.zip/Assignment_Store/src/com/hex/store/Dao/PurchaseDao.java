package com.hex.store.Dao;

import com.hex.store.Exception.InvalidInputException;
import com.hex.store.Model.Purchase;

public interface PurchaseDao {

	public void AddPurchase(Purchase purchase) throws InvalidInputException;
}
