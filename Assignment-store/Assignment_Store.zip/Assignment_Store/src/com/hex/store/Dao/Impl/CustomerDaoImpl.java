package com.hex.store.Dao.Impl;

import com.hex.store.Dao.CustomerDao;

public class CustomerDaoImpl implements CustomerDao{

}
